from warnings import warn

warn("IPython.utils.daemonize has moved to ipyparallel.apps.daemonize")
from ipyparallel.apps.daemonize import daemonize
