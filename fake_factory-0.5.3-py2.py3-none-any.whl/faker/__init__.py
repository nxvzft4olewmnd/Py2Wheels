VERSION = '0.5.3'

from faker.generator import Generator
from faker.factory import Factory

Faker = Factory.create
