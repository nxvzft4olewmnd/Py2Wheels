Mox is a mock object framework for Python based on the
Java mock object framework EasyMock.

