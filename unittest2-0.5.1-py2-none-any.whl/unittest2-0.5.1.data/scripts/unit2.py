#!python

__unittest = True

from unittest2.main import main_

main_()