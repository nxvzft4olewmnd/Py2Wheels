Flaky is an open source project supported by `Box <https://box.com>`_ that was born out of
our testing framework. This is a list of contributors.

- `@Jeff-Meadows <https://github.com/Jeff-Meadows>`_
- `@benpatterson <https://github.com/benpatterson>`_
- `@amygdalama <https://github.com/amygdalama>`_
- `@hugovk <https://github.com/hugovk>`_
