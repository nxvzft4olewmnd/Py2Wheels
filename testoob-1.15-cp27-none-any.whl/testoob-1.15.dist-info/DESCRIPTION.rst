Testoob - Python Testing Out Of (The) Box

Testoob is an advanced unit testing framework for Python. It integrates
effortlessly with existing PyUnit (module "unittest") test suites.

