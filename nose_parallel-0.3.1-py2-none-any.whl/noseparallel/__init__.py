from noseparallel.plugin import ParallelPlugin
