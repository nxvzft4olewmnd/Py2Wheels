"""

=========
Array I/O
=========

Placeholder for array I/O documentation.

"""
